#import "cocos2d.h"
#import "BaseAppController.h"
@class CCLabel;

//CLASS INTERFACE
@interface AppController : BaseAppController
@end

@interface SpriteLayer: CCLayer
{
}
@end

@interface TextLayer: CCLayer
{
}
@end

@interface MainLayer : CCLayer
{
}
@end
