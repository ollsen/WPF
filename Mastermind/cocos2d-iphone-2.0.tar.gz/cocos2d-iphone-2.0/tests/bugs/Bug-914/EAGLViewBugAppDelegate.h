//
//  CCGLViewBugAppDelegate.h
//  CCGLViewBug
//
//  Created by Wylan Werth on 7/5/10.
//  Copyright BanditBear Games 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "cocos2d.h"
#import "bugViewController.h"
#import "BaseAppController.h"

@interface EAGLViewBugAppDelegate : BaseAppController
@end
