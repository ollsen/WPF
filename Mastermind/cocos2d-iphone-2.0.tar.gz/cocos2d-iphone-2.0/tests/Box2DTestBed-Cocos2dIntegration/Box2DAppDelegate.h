//
//  Box2DAppDelegate.h
//  Box2D
//
//  Box2D iPhone port by Simon Oliver - http://www.simonoliver.com - http://www.handcircus.com
//

//
// File heavily modified for cocos2d integration
// http://www.cocos2d-iphone.org
//

#import <UIKit/UIKit.h>
#import "BaseAppController.h"

@class Box2DView;

@interface Box2DAppDelegate : BaseAppController
@end
