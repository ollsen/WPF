#import "cocos2d.h"
#import "BaseAppController.h"

@class CCLabel;

@interface AppController : BaseAppController
@end

@interface TextLayer: CCLayerColor
{
}
@end

