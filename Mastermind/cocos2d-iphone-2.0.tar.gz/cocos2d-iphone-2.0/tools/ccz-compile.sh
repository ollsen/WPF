#!/bin/bash
gcc ccz.c -lz -o ccz 

