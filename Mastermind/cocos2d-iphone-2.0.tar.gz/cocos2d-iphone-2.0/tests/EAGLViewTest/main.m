//
//  main.m
//  CCGLViewTest
//
//  Created by Ricardo Quesada on 09/06/10.
//  Copyright Sapus Media 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {

    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
