
// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"
#import "BaseAppController.h"

// Application Delegate class
@interface AppController : BaseAppController
@end

// HelloActions Layer
@interface ActionsWithBlocks : CCLayer
{
}
@end
