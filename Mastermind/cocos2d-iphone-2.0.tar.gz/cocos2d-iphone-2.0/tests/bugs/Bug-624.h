#import "cocos2d.h"
#import "BaseAppController.h"


//CLASS INTERFACE
@interface AppController : BaseAppController
@end


@interface Layer1 : CCLayer
{
}
@end

@interface Layer2 : CCLayer
{
}
@end
