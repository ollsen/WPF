
#import "BaseAppController.h"
#import "cocos2d.h"

@class JSCocoa;

//CLASS INTERFACE
@interface AppController : BaseAppController
{
	JSCocoa	*javascriptController_;
}
@end
