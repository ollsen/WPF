#import <Foundation/Foundation.h>
#import "cocos2d.h"


@interface QuestionContainerSprite : CCSprite
{

}

@end
