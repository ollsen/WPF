/* TouchesTest (c) Valentin Milea 2009
 */
#import <UIKit/UIKit.h>
#import "cocos2d.h"
#import "BaseAppController.h"

@interface AppController : BaseAppController
@end
